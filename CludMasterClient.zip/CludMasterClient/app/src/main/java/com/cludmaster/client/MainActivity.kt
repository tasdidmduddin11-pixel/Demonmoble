package com.cludmaster.client

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.delay
import java.io.File

const val MC = "com.mojang.minecraftpe"

// ---------- Theme ----------
private val Bg = Color(0xFF0B0E14)
private val Surface1 = Color(0xFF141923)
private val Stroke1 = Color(0xFF222A38)
private val Green = Color(0xFF00E58A)
private val Blue = Color(0xFF00B3FF)
private val Muted = Color(0xFF8A94A6)
private val Danger = Color(0xFFFF5566)
private val AccentBrush = Brush.horizontalGradient(listOf(Green, Blue))

// ---------- Helpers ----------
fun Context.prefs() = getSharedPreferences("client", Context.MODE_PRIVATE)
fun Context.mcInstalled() = packageManager.getLaunchIntentForPackage(MC) != null

fun Context.setCrosshair(on: Boolean) {
    val i = Intent(this, CrosshairService::class.java)
    if (on && Settings.canDrawOverlays(this)) ContextCompat.startForegroundService(this, i) else stopService(i)
}

fun Context.launchMc() {
    val i = packageManager.getLaunchIntentForPackage(MC)
    if (i == null) { Toast.makeText(this, "Minecraft is not installed", Toast.LENGTH_LONG).show(); return }
    if (prefs().getBoolean("xh_on", false)) setCrosshair(true)
    startActivity(i)
}

fun packDir(c: Context) = File(c.filesDir, "packs").apply { mkdirs() }
fun listPacks(c: Context) = packDir(c).listFiles()?.sortedBy { it.name } ?: emptyList()

fun packType(f: File) = when (f.extension.lowercase()) {
    "mcpack" -> "Packs"
    "mcaddon" -> "Addons"
    else -> "Worlds"
}

fun importPack(c: Context, uri: Uri) {
    val name = c.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    } ?: "pack.mcpack"
    val ext = name.substringAfterLast('.', "").lowercase()
    if (ext !in listOf("mcpack", "mcaddon", "mcworld", "mctemplate")) {
        Toast.makeText(c, "Unsupported file type: .$ext", Toast.LENGTH_LONG).show(); return
    }
    c.contentResolver.openInputStream(uri)?.use { i -> File(packDir(c), name).outputStream().use { i.copyTo(it) } }
}

fun installPack(c: Context, f: File) {
    val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", f)
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream")
        .setPackage(MC).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try { c.startActivity(i) } catch (e: Exception) {
        Toast.makeText(c, "Minecraft couldn't open this file", Toast.LENGTH_LONG).show()
    }
}

// ---------- Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Bg)) {
                var splash by remember { mutableStateOf(true) }
                Crossfade(targetState = splash, animationSpec = tween(500), label = "root") { showSplash ->
                    if (showSplash) Splash { splash = false } else App()
                }
            }
        }
    }
}

// ---------- Splash ----------
@Composable
fun Splash(onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(700))
        progress.animateTo(1f, tween(1000, easing = LinearEasing))
        delay(150)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF0C2A25)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.alpha(fade.value).scale(0.85f + 0.15f * fade.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(28.dp)).background(AccentBrush),
                contentAlignment = Alignment.Center
            ) { Text("C", fontSize = 52.sp, fontWeight = FontWeight.Black, color = Color.Black) }
            Spacer(Modifier.height(24.dp))
            Text("CLUD MASTER", fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
            Text("CLIENT  ·  MCPE", fontSize = 12.sp, color = Muted, letterSpacing = 4.sp)
            Spacer(Modifier.height(36.dp))
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier.width(180.dp).height(4.dp).clip(CircleShape),
                color = Green, trackColor = Stroke1
            )
        }
    }
}

// ---------- Shell ----------
@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🏠" to "Home", "🧩" to "Mods", "🎯" to "PvP", "⚡" to "Boost")
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(AccentBrush), contentAlignment = Alignment.Center) {
                Text("C", fontWeight = FontWeight.Black, color = Color.Black)
            }
            Spacer(Modifier.width(10.dp))
            Text("CLUD MASTER", fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
            Text("v0.1", fontSize = 11.sp, color = Green,
                modifier = Modifier.border(1.dp, Green.copy(alpha = .5f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
        }
        Box(Modifier.weight(1f).padding(horizontal = 20.dp)) {
            when (tab) { 0 -> Home(); 1 -> Mods(); 2 -> Pvp(); else -> Boost() }
        }
        // Bottom nav
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp)
                .clip(RoundedCornerShape(24.dp)).background(Surface1)
                .border(1.dp, Stroke1, RoundedCornerShape(24.dp)).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            tabs.forEachIndexed { i, (icon, label) ->
                val sel = tab == i
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                        .background(if (sel) Green.copy(alpha = .15f) else Color.Transparent)
                        .clickable { tab = i }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 18.sp)
                    Text(label, fontSize = 11.sp, color = if (sel) Green else Muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

// ---------- Components ----------
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1)
            .border(1.dp, Stroke1, RoundedCornerShape(20.dp)).padding(16.dp),
        content = content
    )

@Composable
fun StatChip(text: String, ok: Boolean) {
    Text(
        text, fontSize = 12.sp, color = if (ok) Green else Muted,
        modifier = Modifier.clip(CircleShape)
            .background((if (ok) Green else Muted).copy(alpha = .12f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun Title(text: String, sub: String) {
    Text(text, fontSize = 26.sp, fontWeight = FontWeight.Black)
    Text(sub, fontSize = 13.sp, color = Muted)
    Spacer(Modifier.height(14.dp))
}

// ---------- Home ----------
@Composable
fun Home() {
    val c = LocalContext.current
    val p = c.prefs()
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0F4A3C), Color(0xFF0B2236))))
                .border(1.dp, Green.copy(alpha = .25f), RoundedCornerShape(28.dp)).padding(24.dp)
        ) {
            Column {
                Text("READY TO PLAY", fontSize = 11.sp, color = Green, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Minecraft PE", fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text("Your setup loads, then the game starts.", fontSize = 13.sp, color = Muted)
                Spacer(Modifier.height(20.dp))
                Box(
                    Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(18.dp))
                        .background(AccentBrush).clickable { c.launchMc() },
                    contentAlignment = Alignment.Center
                ) { Text("▶  PLAY", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.Black, letterSpacing = 3.sp) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip(if (c.mcInstalled()) "Minecraft found" else "Minecraft missing", c.mcInstalled())
            StatChip(if (p.getBoolean("xh_on", false)) "Crosshair on" else "Crosshair off", p.getBoolean("xh_on", false))
        }
        Panel {
            Text("Quick start", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("1. Add packs in Mods\n2. Set your crosshair in PvP\n3. Pick a preset in Boost\n4. Hit PLAY", color = Muted, fontSize = 13.sp)
        }
    }
}

// ---------- Mods ----------
@Composable
fun Mods() {
    val c = LocalContext.current
    var files by remember { mutableStateOf(listPacks(c)) }
    var filter by remember { mutableStateOf("All") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { importPack(c, uri); files = listPacks(c) }
    }
    Column {
        Title("Mod Manager", "${files.size} item(s) in your library")
        Box(
            Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(16.dp)).background(AccentBrush)
                .clickable { picker.launch(arrayOf("*/*")) },
            contentAlignment = Alignment.Center
        ) { Text("＋  Import pack", fontWeight = FontWeight.Black, color = Color.Black) }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Packs", "Addons", "Worlds").forEach { f ->
                val sel = filter == f
                Text(f, fontSize = 13.sp, color = if (sel) Color.Black else Muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (sel) Green else Surface1)
                        .clickable { filter = f }.padding(horizontal = 14.dp, vertical = 7.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        val shown = files.filter { filter == "All" || packType(it) == filter }
        if (shown.isEmpty()) Text("Nothing here yet.", color = Muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown) { f ->
                val col = when (packType(f)) { "Packs" -> Blue; "Addons" -> Green; else -> Color(0xFFFFB02E) }
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(packType(f), fontSize = 11.sp, color = col, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(CircleShape).background(col.copy(alpha = .15f)).padding(horizontal = 10.dp, vertical = 3.dp))
                        Spacer(Modifier.weight(1f))
                        Text("${f.length() / 1024} KB", fontSize = 12.sp, color = Muted)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(f.nameWithoutExtension, fontWeight = FontWeight.SemiBold)
                    Row {
                        TextButton(onClick = { installPack(c, f) }) { Text("Install", color = Green) }
                        TextButton(onClick = { f.delete(); files = listPacks(c) }) { Text("Remove", color = Danger) }
                    }
                }
            }
        }
    }
}

// ---------- PvP ----------
@Composable
fun Pvp() {
    val c = LocalContext.current
    val p = c.prefs()
    var on by remember { mutableStateOf(p.getBoolean("xh_on", false)) }
    var size by remember { mutableFloatStateOf(p.getInt("xh_size", 24).toFloat()) }
    var color by remember { mutableIntStateOf(p.getInt("xh_color", 0xFF00FF88.toInt())) }
    val colors = listOf(0xFF00FF88, 0xFFFFFFFF, 0xFFFF3355, 0xFF33AAFF, 0xFFFFDD33).map { it.toInt() }

    fun apply() {
        p.edit().putBoolean("xh_on", on).putInt("xh_size", size.toInt()).putInt("xh_color", color).apply()
        c.setCrosshair(on)
    }

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("PvP Tools", "Crosshair overlay")
        Panel {
            Canvas(Modifier.align(Alignment.CenterHorizontally).size(120.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF080A0F))) {
                val half = size.minDimension * (size / 60f).coerceAtMost(1f) / 2f
                val cx = this.size.width / 2; val cy = this.size.height / 2
                val gap = half * 0.24f; val sw = 2.5.dp.toPx(); val col = Color(color)
                drawLine(col, Offset(cx, cy - half), Offset(cx, cy - gap), sw, StrokeCap.Round)
                drawLine(col, Offset(cx, cy + gap), Offset(cx, cy + half), sw, StrokeCap.Round)
                drawLine(col, Offset(cx - half, cy), Offset(cx - gap, cy), sw, StrokeCap.Round)
                drawLine(col, Offset(cx + gap, cy), Offset(cx + half, cy), sw, StrokeCap.Round)
            }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Show crosshair in game", fontWeight = FontWeight.SemiBold)
                    Text("Needs overlay permission", fontSize = 12.sp, color = Muted)
                }
                Switch(checked = on, onCheckedChange = { v ->
                    if (v && !Settings.canDrawOverlays(c)) {
                        c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                    } else { on = v; apply() }
                })
            }
            Spacer(Modifier.height(10.dp))
            Text("Size: ${size.toInt()} dp", fontSize = 12.sp, color = Muted)
            Slider(value = size, onValueChange = { size = it }, valueRange = 12f..60f, onValueChangeFinished = { apply() })
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                colors.forEach { col ->
                    Box(Modifier.size(36.dp).clip(CircleShape).background(Color(col))
                        .border(if (col == color) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { color = col; apply() })
                }
            }
        }
        Panel {
            Text("Tips", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("• Turn on Show Coordinates in your world settings.\n" +
                "• Use a low-fire / short-sword pack from Mods.\n" +
                "• Android doesn't let overlays read taps in other apps, so there's no CPS counter.",
                fontSize = 13.sp, color = Muted)
        }
    }
}

// ---------- Boost ----------
data class Preset(val name: String, val tips: String)

@Composable
fun Boost() {
    val c = LocalContext.current
    val mi = ActivityManager.MemoryInfo().also { (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it) }
    val gb = 1_073_741_824.0
    val total = mi.totalMem / gb; val free = mi.availMem / gb
    val suggested = when { total < 3.5 -> 0; total < 6.5 -> 1; else -> 2 }
    val presets = listOf(
        Preset("Low-end", "Render distance 4–6 · Fancy graphics off · Smooth lighting off · Minimal particles · 16x pack"),
        Preset("Balanced", "Render distance 8–10 · Fancy graphics off · Beautiful skies off · Low-animation pack"),
        Preset("Quality", "Render distance 12+ · Fancy graphics on · Smooth lighting on")
    )
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("FPS Optimizer", "${Build.MANUFACTURER} ${Build.MODEL}")
        Panel {
            Row {
                Text("Memory", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("%.1f / %.1f GB free".format(free, total), fontSize = 12.sp, color = Muted)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { (1f - (free / total).toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Green, trackColor = Stroke1
            )
            Spacer(Modifier.height(10.dp))
            Text("Android ${Build.VERSION.RELEASE} · ${Runtime.getRuntime().availableProcessors()} cores", fontSize = 12.sp, color = Muted)
        }
        presets.forEachIndexed { i, pr ->
            val sel = i == suggested
            Panel(Modifier.border(if (sel) 1.dp else 0.dp, Green.copy(alpha = .6f), RoundedCornerShape(20.dp))) {
                Text(pr.name + if (sel) "  ·  suggested" else "", fontWeight = FontWeight.Bold, color = if (sel) Green else Color.White)
                Spacer(Modifier.height(4.dp))
                Text(pr.tips, fontSize = 13.sp, color = Muted)
            }
        }
        Text("These are recommended in-game settings. Android doesn't let one app change another app's settings, and results vary by device.",
            fontSize = 12.sp, color = Muted)
    }
}
