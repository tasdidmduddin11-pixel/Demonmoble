package com.cludmaster.client

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    private var view: View? = null
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("xh", "Crosshair", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "xh")
            .setContentTitle("Crosshair overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_view).build())
        show()
        return START_STICKY
    }

    private fun show() {
        hide()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val p = getSharedPreferences("client", Context.MODE_PRIVATE)
        val size = p.getInt("xh_size", 24)
        val color = p.getInt("xh_color", 0xFF00FF88.toInt())
        val px = (size * resources.displayMetrics.density).toInt()
        val v = CrosshairView(this, color)
        val lp = WindowManager.LayoutParams(
            px, px,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(v, lp)
        view = v
    }

    private fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    override fun onDestroy() { hide(); super.onDestroy() }
}

class CrosshairView(ctx: Context, color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        strokeWidth = 2.5f * ctx.resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val gap = width * 0.12f
        c.drawLine(cx, 0f, cx, cy - gap, paint)
        c.drawLine(cx, cy + gap, cx, height.toFloat(), paint)
        c.drawLine(0f, cy, cx - gap, cy, paint)
        c.drawLine(cx + gap, cy, width.toFloat(), cy, paint)
    }
}
